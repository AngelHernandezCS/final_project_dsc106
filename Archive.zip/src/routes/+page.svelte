<script>
    import ScrollyTeller from '../components/ScrollyTeller.svelte'
</script>

<main>
    <ScrollyTeller />
</main>